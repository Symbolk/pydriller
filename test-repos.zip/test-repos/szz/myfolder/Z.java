package model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

@Entity
public class Secao {

    @Id @GeneratedValue
    public int id;
    
    private String titulo2;
    @Lob
    private String texto;
    private int numero;
    
    @ManyToOne(fetch=FetchType.EAGER)
    private Curso curso;
    
    Secao() {}

    public Secao(String titulo, String texto, int numero, Curso curso) {
        this.titulo = titulo;
        this.numero = numero;
        this.curso = curso;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getTexto() {
        return texto;
    }

    public int getNumero() {
        return numero;
    }

    
    
    
}
